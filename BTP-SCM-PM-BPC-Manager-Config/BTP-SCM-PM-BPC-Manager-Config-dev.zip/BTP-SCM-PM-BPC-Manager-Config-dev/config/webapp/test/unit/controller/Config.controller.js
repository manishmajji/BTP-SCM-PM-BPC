/*global QUnit*/

sap.ui.define([
	"sce/bpcmanager/config/controller/Config.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Config Controller");

	QUnit.test("I should test the Config controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
