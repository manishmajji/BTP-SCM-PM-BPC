sap.ui.define([
	"sce/bpcmanager/config/test/unit/controller/Config.controller"
], function () {
	"use strict";
});
