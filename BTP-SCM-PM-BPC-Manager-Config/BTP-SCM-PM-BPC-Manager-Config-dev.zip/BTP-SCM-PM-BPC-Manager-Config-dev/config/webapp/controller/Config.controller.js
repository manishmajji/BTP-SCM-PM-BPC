
sap.ui.define([
    "sap/ui/core/mvc/Controller",
      "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel"
], (Controller, MessageToast, MessageBox, Fragment, Filter, FilterOperator, JSONModel) => {
    "use strict";


    return Controller.extend("sce.bpcmanager.config.controller.Config", {
         onInit: function () {
            var oModel = new JSONModel({
                isEdit: false
            });
            this.getView().setModel(oModel, "uiState");
            //assining zero to Workflowstatus_codefilter
            var oComboBox = this.byId("filterWorkflowStatus_code");

            // Insert static null item at index 0 without breaking dynamic binding template
           /* oComboBox.insertItem(new sap.ui.core.Item({
             key: "NULL",
             text: ""
            }), 0);*/
        },

        //enabling delete and edit buttons when a row is selected in the table.For all 6 tables
        onSectionChange: function (oEvent) {
            //if one row is selected 
            var otable = oEvent.getSource();
            var oBinding = otable.getBinding("items");
            var isSelected = otable.getSelectedItems().length > 0;
            var sEditBtnId = otable.data("editButtonId");
            var sDeleteBtnId = otable.data("deleteButtonId");

            if (sEditBtnId) {
                this.byId(sEditBtnId).setEnabled(isSelected);
            }
            if (sDeleteBtnId) {
                this.byId(sDeleteBtnId).setEnabled(isSelected);
            }

        },



        onDeleteStatusWA: function (oEvent) {

            var oButton = oEvent.getSource();
            var sTableId = oButton.data("tableid");

            if (!sTableId) {
                MessageBox.error("Developer Error: CustomData 'tableid' or 'tableId' is missing on the button.");
                return;
            }

            // FIX: Pass the variable sTableId, NOT a literal string "sTableId"
            var oTable = this.byId(sTableId);
            var oSelectedItem = oTable.getSelectedItem();

            if (!oSelectedItem) {
                MessageBox.information("Please select a row to delete.");
                return;
            }

            // Get the OData V4 context of the selected row
            var oContext = oSelectedItem.getBindingContext();
            if (!oContext) {
                MessageBox.error("Unable to locate binding context for deletion.");
                return;
            }

            var sConfirmationMessage = "Are you sure you want to delete Row ?";

            // 1. Prompt user for confirmation before performing destructive action
            MessageBox.confirm(sConfirmationMessage, {
                title: "Confirm Deletion",
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                emphasizedAction: MessageBox.Action.OK,
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        this._executeDeleteRoleUser(oContext, oTable);
                    }
                }.bind(this)
            });
        },

        _executeDeleteRoleUser: function (oContext, oTable) {
            var oView = this.getView();
            oView.setBusy(true);

            // 2. Call OData V4 context delete API
            // In V4, delete() returns a Promise that resolves when HTTP DELETE completes successfully
            oContext.delete("$auto").then(function () {
                oView.setBusy(false);
                MessageToast.show("Role User deleted successfully.");

                // 3. Reset table selection state and disable Action buttons
                oTable.removeSelections(true);
                this.byId("btnStatusEditWARUS").setEnabled(false);
                this.byId("btnStatusDeleteWARUS").setEnabled(false);

            }.bind(this)).catch(function (oError) {
                oView.setBusy(false);

                // 4. Handle errors (e.g., foreign key constraints or server exceptions)
                var sErrorMsg = oError.message || "An error occurred while deleting the record.";
                MessageBox.error("Deletion failed: " + sErrorMsg);
            });
        },
        /*
        onRefreshStatusWA1: function (oEvent) {
            var oButton = oEvent.getSource();
            
            var sTableId = oButton.data("tableid") || oButton.data("tableId");
        
            if (!sTableId) {
                MessageBox.error("Developer Error: CustomData 'tableid' or 'tableId' is missing on the button.");
                return;
            }
        
             Resolve table control using View scope or Core Element registry
            var oTable = this.byId(sTableId) || sap.ui.getCore().byId(sTableId);
        
            if (!oTable) {
                MessageBox.error("Developer Error: Table with ID '" + sTableId + "' could not be located.");
                return;
            }
        
            var oBinding = oTable.getBinding("items");
        
            if (!oBinding) {
                MessageBox.error("Developer Error: No binding found on table items aggregation.");
                return;
            }
            setting busy state to ui
            oTable.setBusy(true);
        
           
            oBinding.refresh().then(function () {
                oTable.setBusy(false);
                MessageToast.show("Data refreshed successfully.");
                oTable.removeSelections(true);
                
                var oEditBtn = this.byId("btnStatusEditWARUS");
                var oDeleteBtn = this.byId("btnStatusDeleteWARUS");
                if (oEditBtn) { oEditBtn.setEnabled(false); }
                if (oDeleteBtn) { oDeleteBtn.setEnabled(false); }
        
            }.bind(this)).catch(function (oError) {
                oTable.setBusy(false);
                var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to refresh data.";
                MessageBox.error("Refresh Error: " + sErrorMsg);
            });
        },*/


        //Refresh button for all tables
        onRefreshStatusWA: function (oEvent) {
            var oButton = oEvent.getSource();

            // Extract custom data table ID
            var sTableId = oButton.data("tableid");

            if (!sTableId) {
                MessageBox.error("Developer Error: CustomData 'tableid' or 'tableId' is missing on the button.");
                return;
            }

            // Resolve table control using View scope
            var oTable = this.byId(sTableId) || sap.ui.getCore().byId(sTableId);

            if (!oTable) {
                MessageBox.error("Developer Error: Table with ID '" + sTableId + "' could not be located.");
                return;
            }

            var oBinding = oTable.getBinding("items");

            if (!oBinding) {
                MessageBox.error("Developer Error: No binding found on table items aggregation.");
                return;
            }

            // Set UI to busy state
            oTable.setBusy(true);

            try {
                // OData V4 refresh trigger
                oBinding.refresh();

                // Handle completion via dataReceived event or short delay safety
                var fnDataReceived = function (oEventReceived) {
                    oTable.setBusy(false);
                    oBinding.detachDataReceived(fnDataReceived);

                    var oError = oEventReceived.getParameter("error");
                    if (oError) {
                        var sErrorMsg = oError.message || "Failed to refresh data.";
                        MessageBox.error("Refresh Error: " + sErrorMsg);
                    } else {
                        MessageToast.show("Data refreshed successfully.");
                        oTable.removeSelections(true);
                        // make changes for generalization
                        var oEditBtn = this.byId("btnStatusEditWARUS");
                        var oDeleteBtn = this.byId("btnStatusDeleteWARUS");
                        if (oEditBtn) { oEditBtn.setEnabled(false); }
                        if (oDeleteBtn) { oDeleteBtn.setEnabled(false); }
                    }
                }.bind(this);

                oBinding.attachDataReceived(fnDataReceived);

            } catch (oErr) {
                oTable.setBusy(false);
                MessageBox.error("Refresh execution error: " + (oErr.message || oErr.toString()));
            }
        },


        onOpenCreateDialogWfA: async function (oEvent) {
            var oView = this.getView();
            var oButton = oEvent.getSource();
            var sTableId = oButton.data("tableid");

            var oTable = this.byId(sTableId);
            //var oTable = this.byId("tableWorkflowAction");
            var oListBinding = oTable.getBinding("items");
            //Asking generating KEY

            var sGeneratedCode = await new Promise(function (resolve) {
                var oInput = new sap.m.Input({ placeholder: "Enter Key..." });

                sap.m.MessageBox.show(oInput, {
                    icon: sap.m.MessageBox.Icon.QUESTION,
                    title: "Enter Code",
                    actions: [sap.m.MessageBox.Action.OK],
                    onClose: function (sAction) {
                        if (sAction === sap.m.MessageBox.Action.OK) {
                            resolve(oInput.getValue().trim()); // Resume & return the entered value
                        } else {
                            resolve(null); // Resume & return null if cancelled
                        }
                    }
                });
            });

            var iQuestionId = parseInt(sGeneratedCode, 10);
            if (!oListBinding) {
                MessageBox.error("Table list binding for " + oTable + " was not found.");
                return;
            }
            switch (sTableId) {
                case "tableWorkflowAction":
                    // 1. Create a transient OData V4 context
                    var oNewContext = oListBinding.create({
                        "ActionID": sGeneratedCode,
                        "ShortText": "",
                        "LongText": "",
                        "WorkflowStatus_code": "",
                        "CommentsRequired": false
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.WorkflowActionDialog";
                    break;
                 case "tableFormWizard":
                    // 1. Create a transient OData V4 context
                    var oNewContext = oListBinding.create({
                        "QuestionId": isNaN(iQuestionId) ? 0 : iQuestionId,
                        "Question": "",
                        "YesQuestionId": 0,
                        "NoQuestionId": 0,
                        "ShowCreate": "Yes"
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.FormWizardDialog";
                    break;
                case "tableWorkflowStatus":
                    var oNewContext = oListBinding.create({
                        "code": sGeneratedCode,
                        "Description": "",
                        "InitialStatus": false,
                        "StartWorkflow": false,
                        "EndWorkflow": false
                    });

                    var oPathFragmen = "sce.bpcmanager.config.fragments.WorkflowStatusDialog";
                    break;
                case "tableRoleUsers":
                    var oNewContext = oListBinding.create({
                        "RoleUserID": sGeneratedCode,
                        "RoleID_RoleID": "",
                        "UserID": ""
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.RoleUsersDialog";
                    break;
                case "tableWorkflowRole":
                    // 1. Create a transient OData V4 context
                    var oNewContext = oListBinding.create({
                        "RoleID": sGeneratedCode,
                        "RoleName": "",
                        "InitialRole": false
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.WorkflowRoleDialog";
                    break;
                case "WorkflowRoleStatusSet":
                    // 1. Create a transient OData V4 context
                    var oNewContext = oListBinding.create({
                        "StatusID": sGeneratedCode,
                        "Role_RoleID": "",
                        "WorkflowStatus_code": "",
                        "Editable": false
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.WorkflowRoleStatusDialog";
                    break;
                case "tableWorkflowStep":
                    // 1. Create a transient OData V4 context
                    var oNewContext = oListBinding.create({
                        "StepID": sGeneratedCode,
                        "RoleFrom_RoleID": "",
                        "RoleTo_RoleID": "",
                        "Action_ActionID": "",
                        "CheckStatus_code": "",
                        "ValidateData": false,
                        "LeaveDb": false
                    });
                    var oPathFragmen = "sce.bpcmanager.config.fragments.WorkflowStepDialog";
                    break;
            };


            this._oCurrentWFAContext = oNewContext;


            // 2. Load Dialog Fragment asynchronously 
            if (!this._mDialogs) {
                this._mDialogs = {}; // Initialize dialog registry object
            }

            // Check if THIS specific fragment path has been loaded yet
            if (!this._mDialogs[oPathFragmen]) {
                this._mDialogs[oPathFragmen] = Fragment.load({
                    id: oView.getId(),
                    name: oPathFragmen,
                    controller: this
                }).then(function (oDialog) {
                    oView.addDependent(oDialog);
                    return oDialog;
                });
            }

            // Await the promise specific to the requested fragment
            var oDialog = await this._mDialogs[oPathFragmen];

            //var oDialog = await this._pWFADialog;

            // 3. Set UI state to Create mode (enables Key fields)
            var oUiModel = oView.getModel("uiState");
            if (oUiModel) {
                oUiModel.setProperty("/isEdit", false);
            }

            // 4. Bind transient context to Dialog and open
            oDialog.setBindingContext(oNewContext);
            oDialog.open();

        },


        onOpenEditDialogWfA: async function (oEvent) {
            var oView = this.getView();
            var oButton = oEvent.getSource();
            var sTableId = oButton.data("tableid");
            var oTable = this.byId(sTableId);

            if (!oTable) {
                MessageBox.error("Table context could not be determined.");
                return;
            }

            var oSelectedItem = oTable.getSelectedItem();
            if (!oSelectedItem) {
                MessageBox.information("Please select a row to edit.");
                return;
            }

            var oSelectedContext = oSelectedItem.getBindingContext();
            if (!oSelectedContext) {
                MessageBox.error("Unable to locate binding context for selected row.");
                return;
            }

            this._oCurrentWFAContext = oSelectedContext;

            //var oName ="sce.bpcmanager.config.fragments.WorkflowActionDialog";
            switch (sTableId) {
                case "tableWorkflowAction":

                    var oName = "sce.bpcmanager.config.fragments.WorkflowActionDialog";
                    break;
                case "tableFormWizard":

                    var oName = "sce.bpcmanager.config.fragments.FormWizardDialog";
                    break;
                case "tableWorkflowStatus":

                    var oName = "sce.bpcmanager.config.fragments.WorkflowStatusDialog";
                    break;
                case "tableRoleUsers":

                    var oName = "sce.bpcmanager.config.fragments.RoleUsersDialog";
                    break;
                case "tableWorkflowRole":

                    var oName = "sce.bpcmanager.config.fragments.WorkflowRoleDialog";
                    break;
                case "WorkflowRoleStatusSet":

                    var oName = "sce.bpcmanager.config.fragments.WorkflowRoleStatusDialog";
                    break;
                case "tableWorkflowStep":

                    var oName = "sce.bpcmanager.config.fragments.WorkflowStepDialog";
                    break;
            };


            // 2. Load Dialog Fragment asynchronously (Map per fragment path)
            if (!this._mDialogs) {
                this._mDialogs = {};
            }

            // Check if THIS specific fragment path has been loaded yet
            if (!this._mDialogs[oName]) {
                this._mDialogs[oName] = Fragment.load({
                    id: oView.getId(),
                    name: oName,
                    controller: this
                }).then(function (oDialog) {
                    oView.addDependent(oDialog);
                    return oDialog;
                });
            }

            // Await the promise specific to the requested fragment
            var oDialog = await this._mDialogs[oName];

            //var oDialog = await this._pWFADialog;

            // 2. Set UI state to Edit mode (disables Key field editing)
            var oUiModel = oView.getModel("uiState");
            if (oUiModel) {
                oUiModel.setProperty("/isEdit", true);
            }

            // 3. Bind selected row's context to the Dialog and open
            oDialog.setBindingContext(oSelectedContext);
            oDialog.open();
        },

        onSaveStatusWFA: function (oEvent) {
            var oView = this.getView();
            var oModel = oView.getModel(); // Main OData V4 Model
            var bIsEdit = oView.getModel("uiState").getProperty("/isEdit");
            var oButton = oEvent.getSource();
            var sTableId = oButton.data("sTableId");
            switch (sTableId) {
                case "tableWorkflowAction":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sActionID = this._oCurrentWFAContext.getProperty("ActionID");
                        var sShortText = this._oCurrentWFAContext.getProperty("ShortText");
                        var sStatusCode = this._oCurrentWFAContext.getProperty("WorkflowStatus_code");

                        if (!sActionID || !sActionID.trim()) {
                            MessageBox.error("Action ID is required.");
                            return;
                        }
                        if (!sShortText || !sShortText.trim()) {
                            MessageBox.error("Short Text is required.");
                            return;
                        }
                        if (!sStatusCode || !sStatusCode.trim()) {
                            MessageBox.error("Workflow Status Code is required.");
                            return;
                        }
                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create Workflow Action. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Action updated successfully." : "Workflow Action created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
                case "tableWorkflowStatus":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var scode = this._oCurrentWFAContext.getProperty("code");
                        //var Description = this._oCurrentWFAContext.getProperty("ShortText");
                        //var InitialStatus = this._oCurrentWFAContext.getProperty("WorkflowStatus_code");

                        if (!scode || !scode.trim()) {
                            MessageBox.error("code is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    //more than one batch entries :creat read get
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create Workflow Action. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Action updated successfully." : "Workflow Action created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
                case "tableFormWizard":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sQuestionId = this._oCurrentWFAContext.getProperty("QuestionId");
                        //var Description = this._oCurrentWFAContext.getProperty("ShortText");
                        //var InitialStatus = this._oCurrentWFAContext.getProperty("WorkflowStatus_code");

                        if (!sQuestionId) {
                            MessageBox.error("QuestionId is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    //more than one batch entries :creat read get
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create FormWizard. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "FormWizard updated successfully." : "FormWizard created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
               
                    case "tableRoleUsers":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sRoleUserID = this._oCurrentWFAContext.getProperty("RoleUserID");

                        if (!sRoleUserID || !sRoleUserID.trim()) {
                            MessageBox.error("RoleUserID is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (((!bIsEdit) && (this._oCurrentWFAContext)) && (this._oCurrentWFAContext.isTransient())) {
                            MessageBox.error("Failed to create Workflow Action. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Action updated successfully." : "Workflow Action created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;

                case "tableWorkflowRole":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sRoleID = this._oCurrentWFAContext.getProperty("RoleID");

                        if (!sRoleID || !sRoleID.trim()) {
                            MessageBox.error("RoleID is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create Workflow Action. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Role updated successfully." : "Workflow Role created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
                case "WorkflowRoleStatusSet":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sStatusID = this._oCurrentWFAContext.getProperty("StatusID");

                        if (!sStatusID || !sStatusID.trim()) {
                            MessageBox.error("StatusID is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create Workflow RoleStatus. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Role status updated successfully." : "Workflow status created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
                case "tableWorkflowStep":

                    // Client-side validation checks on bound context properties
                    if (this._oCurrentWFAContext) {
                        var sStepID = this._oCurrentWFAContext.getProperty("StepID");

                        if (!sStepID || !sStepID.trim()) {
                            MessageBox.error("StepID is required.");
                            return;
                        }

                    }

                    oView.setBusy(true);

                    // Submit pending changes ($auto batch group handles POST or PATCH)
                    oModel.submitBatch("$auto").then(function () {
                        oView.setBusy(false);

                        if (!bIsEdit && this._oCurrentWFAContext && this._oCurrentWFAContext.isTransient()) {
                            MessageBox.error("Failed to create Workflow Action. Please check inputs or backend logs.");
                        } else {
                            MessageToast.show(bIsEdit ? "Workflow Action updated successfully." : "Workflow Action created successfully.");
                            this._oCurrentWFAContext = null;
                            this._closeWFADialog(oEvent);
                        }
                    }.bind(this)).catch(function (oError) {
                        oView.setBusy(false);
                        var sErrorMsg = oError ? (oError.message || oError.toString()) : "Failed to execute save request.";
                        MessageBox.error("Save Error: " + sErrorMsg);
                    }.bind(this));
                    break;
            };



        },


        // Close Dialog and reset transient context if canceled during creation

        onCloseStatusDialogWFA: function (oEvent) {
            var bIsEdit = this.getView().getModel("uiState").getProperty("/isEdit");

            if ((!bIsEdit && this._oCurrentWFAContext) || (this._oCurrentWFAContext.isTransient())) {
                this._oCurrentWFAContext.delete().catch(function (oError) {
                    // Ignore the expected transient cancellation error
                    if (!oError || !oError.canceled) {
                        // Log only real errors if needed
                        console.error("Error deleting context:", oError);
                    }
                });
            }

            this._oCurrentWFAContext = null;
            this._closeWFADialog(oEvent);

        },

        _closeWFADialog: function (oEvent) {

            if (oEvent) {

                var oSource = oEvent.getSource();
                var oDialog = oSource.getParent();
                while (oDialog && !oDialog.isA("sap.m.Dialog")) {
                    oDialog = oDialog.getParent();
                }

                if (oDialog) {
                    oDialog.close();

                }
            }
        },

        onSearchStatus: function () {
            var aFilters = [];

            // 1. Read input values from filter controls
            var sActionID = this.byId("filterActionID").getValue();
            var sShortText = this.byId("filterShortText").getValue();
            var sLongText = this.byId("filterLongText").getValue();
            var sStatusCode = this.byId("filterWorkflowStatuscode").getValue();
            var sCommentsReq = this.byId("filterCommentsRequired").getSelectedKey();

            // 2. Build Filter instances using FilterOperator.Contains for string searches
            if (sActionID && sActionID.trim()) {
                aFilters.push(new Filter("ActionID", FilterOperator.Contains, sActionID.trim(), false));
            }
            if (sShortText && sShortText.trim()) {
                aFilters.push(new Filter("ShortText", FilterOperator.Contains, sShortText.trim(), false));
            }
            if (sLongText && sLongText.trim()) {
                aFilters.push(new Filter("LongText", FilterOperator.Contains, sLongText.trim(), false));
            }
            if (sStatusCode && sStatusCode.trim()) {
                aFilters.push(new Filter("WorkflowStatus_code", FilterOperator.Contains, sStatusCode.trim(), false));
            }

            // 3. Handle Boolean type filtering (EQ operator)
            if (sCommentsReq !== "") {
                var bCommentsReq = sCommentsReq === "true";
                aFilters.push(new Filter("CommentsRequired", FilterOperator.EQ, bCommentsReq));
            }

            // 4. Retrieve Table List Binding and apply filters
            var oTable = this.byId("tableWorkflowAction");
            var oListBinding = oTable.getBinding("items");

            if (oListBinding) {
                // In OData V4, filter() triggers a GET request with $filter query options
                oListBinding.filter(aFilters);
                MessageToast.show("Filters applied successfully.");
            } else {
                MessageBox.error("Unable to locate table binding for filtering.");
            }
        },
        onSearchStatusRUS: function () {
            var aFilters = [];

            // 1. Fetch values from controls
            var sRoleUserID = this.byId("filterRoleUserID").getValue().trim();
            var sRoleID = this.byId("filterRoleIDRoleID").getSelectedKey() || this.byId("filterRoleIDRoleID").getValue().trim();
            var sUserID = this.byId("filterUserID").getValue().trim();

            // 2. Build Filter array with bCaseSensitive = false
            // Syntax: new Filter(path, operator, value1, bCaseSensitive)
            if (sRoleUserID) {
                aFilters.push(new Filter("RoleUserID", FilterOperator.Contains, sRoleUserID, false));
            }
            if (sRoleID) {
                aFilters.push(new Filter("RoleID_RoleID", FilterOperator.Contains, sRoleID, false));
            }
            if (sUserID) {
                aFilters.push(new Filter("UserID", FilterOperator.Contains, sUserID, false));
            }

            // 3. Apply filters to table binding
            var oTable = this.byId("tableRoleUsers");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },
        onSearchStatusWFRS: function () {
            var aFilters = [];

            // 1. Get input values
            var sRoleID = this.byId("filterRoleID").getValue().trim();
            var sRoleName = this.byId("filterRoleName").getValue().trim();
            var sInitialRole = this.byId("filterInitialRole").getSelectedKey();

            // 2. Build filters
            if (sRoleID) {
                aFilters.push(new Filter("RoleID", FilterOperator.Contains, sRoleID));
            }
            if (sRoleName) {
                aFilters.push(new Filter("RoleName", FilterOperator.Contains, sRoleName));
            }
            // Boolean comparison for InitialRole (true/false)
            if (sInitialRole !== "") {
                var bInitialRole = (sInitialRole === "true");
                aFilters.push(new Filter("InitialRole", FilterOperator.EQ, bInitialRole));
            }

            // 3. Apply filters to table binding
            var oTable = this.byId("tableWorkflowRole");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },
        onSearchStatusWSS: function () {
            var aFilters = [];

            // 1. Fetch values from form controls
            var sCode = this.byId("filtercode").getValue().trim();
            var sDescription = this.byId("filterDescription").getValue().trim();
            var sInitialStatus = this.byId("filterInitialStatus").getSelectedKey();
            var sStartWorkflow = this.byId("filterStartWorkflow").getSelectedKey();
            var sEndWorkflow = this.byId("filterEndWorkflow").getSelectedKey();

            // 2. String filters (Contains)
            if (sCode) {
                aFilters.push(new Filter("code", FilterOperator.Contains, sCode,false));
            }
            if (sDescription) {
                aFilters.push(new Filter("Description", FilterOperator.Contains, sDescription));
            }

            // 3. Boolean filters (EQ)
            if (sInitialStatus !== "") {
                aFilters.push(new Filter("InitialStatus", FilterOperator.EQ, sInitialStatus === "true"));
            }
            if (sStartWorkflow !== "") {
                aFilters.push(new Filter("StartWorkflow", FilterOperator.EQ, sStartWorkflow === "true"));
            }
            if (sEndWorkflow !== "") {
                aFilters.push(new Filter("EndWorkflow", FilterOperator.EQ, sEndWorkflow === "true"));
            }

            // 4. Apply to table binding
            var oTable = this.byId("tableWorkflowStatus");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },

        onSearchStatusWFRSS: function () {
            var aFilters = [];

            // 1. Fetch values from form controls
            var sStatusID = this.byId("filterStatusID").getValue().trim();
            var sRoleID = this.byId("filterRole_RoleID").getSelectedKey() || this.byId("filterRole_RoleID").getValue().trim();
            var sStatusCode = this.byId("filterWorkflowStatus_code").getSelectedKey() || this.byId("filterWorkflowStatus_code").getValue().trim();
            var sEditable = this.byId("filterEditable").getSelectedKey();

            // 2. String/Key filters
            if (sStatusID) {
                aFilters.push(new Filter("StatusID", FilterOperator.Contains, sStatusID));
            }
            if (sRoleID) {
                aFilters.push(new Filter("Role_RoleID", FilterOperator.Contains, sRoleID));
            }
            if (sStatusCode) {
                aFilters.push(new Filter("WorkflowStatus_code", FilterOperator.Contains, sStatusCode));
            }

            // 3. Boolean filter (Editable)
            if (sEditable !== "") {
                aFilters.push(new Filter("Editable", FilterOperator.EQ, sEditable === "true"));
            }

            // 4. Apply to table binding
            var oTable = this.byId("WorkflowRoleStatusSet");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },
        onSearchStatusWFStS: function () {
            var aFilters = [];

            // 1. Fetch values from form controls
            var sStepID = this.byId("filterStepID").getValue().trim();
            var sRoleFrom = this.byId("filterRoleFromRoleID").getSelectedKey() || this.byId("filterRoleFromRoleID").getValue().trim();
            var sRoleTo = this.byId("filterRoleToRoleID").getSelectedKey() || this.byId("filterRoleToRoleID").getValue().trim();
            var sAction = this.byId("filterActionActionID").getSelectedKey() || this.byId("filterActionActionID").getValue().trim();
            var sCheckStatus = this.byId("filterCheckStatuscode").getSelectedKey() || this.byId("filterCheckStatuscode").getValue().trim();
            var sValidateData = this.byId("filterValidateData").getSelectedKey();
            var sLeaveDb = this.byId("filterLeaveDb").getSelectedKey();

            // 2. String/Key filters (Contains)
            if (sStepID) {
                aFilters.push(new Filter("StepID", FilterOperator.Contains, sStepID));
            }
            if (sRoleFrom) {
                aFilters.push(new Filter("RoleFrom_RoleID", FilterOperator.Contains, sRoleFrom));
            }
            if (sRoleTo) {
                aFilters.push(new Filter("RoleTo_RoleID", FilterOperator.Contains, sRoleTo));
            }
            if (sAction) {
                aFilters.push(new Filter("Action_ActionID", FilterOperator.Contains, sAction));
            }

            // 3. Special handling for CheckStatus_code (NULL vs standard search)
            if (sCheckStatus === "NULL") {
                aFilters.push(new Filter("CheckStatus_code", FilterOperator.EQ, null));
            } else if (sCheckStatus) {
                aFilters.push(new Filter("CheckStatus_code", FilterOperator.Contains, sCheckStatus));
            }

            // 4. Boolean filters (EQ)
            if (sValidateData !== "") {
                aFilters.push(new Filter("ValidateData", FilterOperator.EQ, sValidateData === "true"));
            }
            if (sLeaveDb !== "") {
                aFilters.push(new Filter("LeaveDb", FilterOperator.EQ, sLeaveDb === "true"));
            }

            // 5. Apply to table binding
            var oTable = this.byId("tableWorkflowStep");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },
    
onSearchStatusFW: function () {
    var aFilters = [];

    // 1. Helper to handle MultiComboBox controls (OR condition within same field)
    var fnAddMultiFilter = function (sControlId, sPropertyName) {
        var oMultiComboBox = this.byId(sControlId);
        if (oMultiComboBox && oMultiComboBox.getSelectedKeys) {
            var aSelectedKeys = oMultiComboBox.getSelectedKeys();
            if (aSelectedKeys && aSelectedKeys.length > 0) {
                var aFieldFilters = aSelectedKeys.map(function (sKey) {
                    return new Filter(sPropertyName, FilterOperator.EQ, sKey);
                });
                aFilters.push(new Filter({
                    filters: aFieldFilters,
                    and: false
                }));
            }
        }
    }.bind(this);

    // 2. Helper to handle Select controls (Single key comparison)
    var fnAddSelectFilter = function (sControlId, sPropertyName) {
        var oSelect = this.byId(sControlId);
        if (oSelect && oSelect.getSelectedKey) {
            var sSelectedKey = oSelect.getSelectedKey();
            // Ignore empty key ("") which represents "ALL"
            if (sSelectedKey !== "" && sSelectedKey !== null && sSelectedKey !== undefined) {
                aFilters.push(new Filter(sPropertyName, FilterOperator.EQ, sSelectedKey));
            }
        }
    }.bind(this);

    // Collect MultiComboBox filters
    fnAddMultiFilter("filterQuestionId", "QuestionId");
    fnAddMultiFilter("filterQuestion", "Question");
    fnAddMultiFilter("filterYesQuestionId", "YesQuestionId");
    fnAddMultiFilter("filterNoQuestionId", "NoQuestionId");

    // Collect Select filter for ShowCreate and CommentsRequired
    fnAddSelectFilter("filterShowCreate", "ShowCreate");
    fnAddSelectFilter("filterCommentsRequired", "CommentsRequired");

    // Apply combined filters to table binding
    var oTable = this.byId("tableFormWizard");
    var oBinding = oTable ? oTable.getBinding("items") : null;

    if (oBinding) {
        oBinding.filter(aFilters);
    }
},

onResetFiltersFW: function () {
    // 1. List of MultiComboBox control IDs
    var aMultiComboBoxIds = [
        "filterQuestionId",
        "filterQuestion",
        "filterYesQuestionId",
        "filterNoQuestionId"
    ];

    // Reset MultiComboBox selections
    aMultiComboBoxIds.forEach(function (sId) {
        var oControl = this.byId(sId);
        if (oControl && oControl.setSelectedKeys) {
            oControl.setSelectedKeys([]);
            if (oControl.setValue) {
                oControl.setValue("");
            }
        }
    }.bind(this));

    // 2. List of Select control IDs
    var aSelectIds = [
        "filterShowCreate",
        "filterCommentsRequired"
    ];

    // Reset Select dropdowns back to "ALL" (key: "")
    aSelectIds.forEach(function (sId) {
        var oSelect = this.byId(sId);
        if (oSelect && oSelect.setSelectedKey) {
            oSelect.setSelectedKey("");
        }
    }.bind(this));

    // 3. Clear table filters
    var oTable = this.byId("tableFormWizard");
    var oBinding = oTable ? oTable.getBinding("items") : null;

    if (oBinding) {
        oBinding.filter([]);
    }
},

        onResetFiltersWFStS: function () {
            // 1. Clear input field
            this.byId("filterStepID").setValue("");

            // 2. Clear ComboBox selections and typed text
            var aComboBoxIds = [
                "filterRoleFromRoleID",
                "filterRoleToRoleID",
                "filterActionActionID",
                "filterCheckStatuscode"
            ];

            aComboBoxIds.forEach(function (sId) {
                var oControl = this.byId(sId);
                if (oControl) {
                    oControl.setSelectedKey("");
                    oControl.setValue("");
                }
            }.bind(this));

            // 3. Reset Select dropdowns to "All"
            this.byId("filterValidateData").setSelectedKey("");
            this.byId("filterLeaveDb").setSelectedKey("");

            // 4. Clear table filters
            var oTable = this.byId("tableWorkflowStep");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter([]);
            }
        },

        onResetFiltersWFRSS: function () {
            // 1. Clear input field
            this.byId("filterStatusID").setValue("");

            // 2. Clear ComboBox selections and typed text
            this.byId("filterRole_RoleID").setSelectedKey("");
            this.byId("filterRole_RoleID").setValue("");
            this.byId("filterWorkflowStatus_code").setSelectedKey("");
            this.byId("filterWorkflowStatus_code").setValue("");

            // 3. Reset Select dropdown to "All"
            this.byId("filterEditable").setSelectedKey("");

            // 4. Clear table filters
            var oTable = this.byId("WorkflowRoleStatusSet");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter([]);
            }
        },
        onResetFiltersWSS: function () {
            // 1. Reset inputs
            this.byId("filtercode").setValue("");
            this.byId("filterDescription").setValue("");

            // 2. Reset dropdown selects to "ALL"
            this.byId("filterInitialStatus").setSelectedKey("");
            this.byId("filterStartWorkflow").setSelectedKey("");
            this.byId("filterEndWorkflow").setSelectedKey("");

            // 3. Clear table filters
            var oTable = this.byId("tableWorkflowStatus");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter([]);
            }
        },
        onResetFilters: function () {
            // 1. Clear input control values
            this.byId("filterActionID").setValue("");
            this.byId("filterShortText").setValue("");
            this.byId("filterLongText").setValue("");
            this.byId("filterWorkflowStatuscode").setValue("");
            this.byId("filterCommentsRequired").setSelectedKey("");

            // 2. Clear filters on the binding by passing an empty array or undefined
            var oTable = this.byId("tableWorkflowAction");
            var oListBinding = oTable.getBinding("items");

            if (oListBinding) {
                oListBinding.filter([]);
                MessageToast.show("Filters reset.");
            }
        },
        onResetFiltersRUS: function () {
            // 1. Clear input values
            this.byId("filterRoleUserID").setValue("");
            this.byId("filterRoleIDRoleID").setSelectedKey("");
            this.byId("filterRoleIDRoleID").setValue("");
            this.byId("filterUserID").setValue("");

            // 2. Clear table filters
            var oTable = this.byId("tableRoleUsers");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter([]);
            }
        },
        onResetFiltersWFRS: function () {
            // 1. Reset inputs
            this.byId("filterRoleID").setValue("");
            this.byId("filterRoleName").setValue("");
            this.byId("filterInitialRole").setSelectedKey("");

            // 2. Clear filters from table binding
            var oTable = this.byId("tableWorkflowRole");
            var oBinding = oTable.getBinding("items");

            if (oBinding) {
                oBinding.filter([]);
            }
        },
        /*onKeyCodeChange: function (oEvent) {
            var sNewValue = oEvent.getParameter("value");
            // Explicitly set the OData v4 transient context property directly
            if (this._oCurrentWFAContext) {
                this._oCurrentWFAContext.setProperty("code", sNewValue);
            }
        },*/
        onShowCreateSwitchChange: function (oEvent) {
    var bState = oEvent.getParameter("state");
    var oContext = oEvent.getSource().getBindingContext();
    oContext.setProperty("ShowCreate", bState ? "Yes" : "No");
}

    });
});